import whisper
import sounddevice as sd
import numpy as np
import queue
import time
import torch
import os
import scipy.io.wavfile as wav
import webrtcvad  # Ensure this is installed: pip install webrtcvad

# Use a sample rate supported by WebRTC VAD (e.g., 16000 Hz)
SAMPLE_RATE = 16000  # Changed from 44100 to 16000 for VAD compatibility
CHANNELS = 1         # Mono audio
BLOCKSIZE = 1024     # Size of each audio chunk

# Load Whisper model (initialized once to avoid reloading)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
model = whisper.load_model("small", device=DEVICE)

# Queue for storing audio data
audio_queue = queue.Queue()

# Initialize VAD (mode 3 MOST AGGRESSIVE)
vad = webrtcvad.Vad(3)

# Function to capture audio in real-time
def callback(indata, frames, time_info, status):
    """Collects microphone input into a queue."""
    if status:
        print(status)
    audio_queue.put(indata.copy())

def record_audio(duration):
    """Records audio from the microphone for a given fixed duration."""
    print(f"Recording for {duration} seconds...")
    audio_data = []
    
    with sd.InputStream(samplerate=SAMPLE_RATE, channels=CHANNELS,
                        callback=callback, blocksize=BLOCKSIZE):
        for _ in range(int(SAMPLE_RATE / BLOCKSIZE * duration)):
            audio_data.append(audio_queue.get())

    audio_array = np.concatenate(audio_data, axis=0)
    return audio_array

def is_chunk_speech(chunk, sample_rate=SAMPLE_RATE, frame_duration_ms=30):
    """
    Determines whether an audio chunk contains speech using WebRTC VAD.
    Converts the float32 audio (range -1.0 to 1.0) to 16-bit PCM.
    Splits the chunk into frames of `frame_duration_ms` milliseconds.
    Returns True if any frame is detected as speech.
    """
    chunk_int16 = (chunk * 32767).astype(np.int16)
    pcm_bytes = chunk_int16.tobytes()

    frame_size = int(sample_rate * (frame_duration_ms / 1000.0))  # samples per frame
    bytes_per_frame = frame_size * 2  # 2 bytes per sample (16-bit)
    
    for i in range(0, len(pcm_bytes), bytes_per_frame):
        frame = pcm_bytes[i:i+bytes_per_frame]
        if len(frame) < bytes_per_frame:
            break  # Skip incomplete frame
        if vad.is_speech(frame, sample_rate):
            return True
    return False

def compute_rms(audio_chunk):
    """Computes the RMS (Root Mean Square) volume of an audio chunk."""
    return np.sqrt(np.mean(audio_chunk**2))

def is_white_noise(audio_chunk, rms_threshold=0.08):
    """
    Determines if the audio chunk contains white noise based on low RMS
    and low fluctuations in amplitude (indicating no clear speech patterns).
    """
    rms_value = compute_rms(audio_chunk)
    
    if rms_value < rms_threshold:
        stddev = np.std(audio_chunk)
        
        if stddev < 0.01:  # Adjust this based on testing
            return True
    return False

def record_audio_until_silence_or_noise():
    """
    Records audio until silence or white noise is detected.
    Uses both VAD and RMS volume threshold for stopping criteria.
    """
    print("Recording command until silence or white noise is detected...")
    audio_data = []
    
    silence_duration = 5 # Must be silent for this duration to stop
    noise_duration = 5   # Must be white noise for this duration to stop
    silence_timer = 0.0     # Timer to track continuous silence
    noise_timer = 0.0       # Timer to track white noise duration
    RMS_THRESHOLD = 0.03    # Low sensitivity for quieter sounds

    with sd.InputStream(samplerate=SAMPLE_RATE, channels=CHANNELS,
                        callback=callback, blocksize=BLOCKSIZE):
        while True:
            audio_chunk = audio_queue.get()
            audio_data.append(audio_chunk)

            rms_value = compute_rms(audio_chunk)  # Compute RMS
            is_speech = is_chunk_speech(audio_chunk, sample_rate=SAMPLE_RATE)
            is_noise = is_white_noise(audio_chunk, rms_threshold=RMS_THRESHOLD)

            # Check for silence or no speech
            if not is_speech and rms_value < RMS_THRESHOLD:
                silence_timer += BLOCKSIZE / SAMPLE_RATE
                print(f"VAD: no speech | RMS: {rms_value:.6f} (silence_timer = {silence_timer:.2f})")
            else:
                silence_timer = 0.0  # Reset timer if speech or volume is detected
                print(f"VAD: speech detected | RMS: {rms_value:.6f} (Reset silence timer)")

            # If white noise is detected, accumulate time
            if is_noise:
                noise_timer += BLOCKSIZE / SAMPLE_RATE
                print(f"White noise detected (noise_timer = {noise_timer:.2f})")
            else:
                noise_timer = 0.0  # Reset noise timer if speech or other sounds detected

            # Stop recording if either silence or noise exceeds the threshold duration
            if silence_timer >= silence_duration or noise_timer >= noise_duration:
                print("Silence or white noise detected. Stopping command recording.")
                break

    audio_array = np.concatenate(audio_data, axis=0)
    return audio_array

def transcribe_audio(audio_array):
    """Transcribes recorded audio using Whisper."""
    print("Processing audio for transcription...")
    temp_filename = "temp_audio.wav"
    
    # Save audio data to a temporary WAV file using scipy.io.wavfile
    wav.write(temp_filename, SAMPLE_RATE, audio_array)
    
    # Transcribe the audio using the model
    result = model.transcribe(temp_filename)
    
    # Delete the temporary file
    os.remove(temp_filename)
    
    return result['text']

def listen_for_wake_word():
    """Continuously listens for the wake word before starting command recording."""
    print("Listening for 'hello'...")

    wake_word_timeout = 7.0  # Exit if no wake word for this duration
    wake_word_timer = 0.0    # Tracks inactivity duration

    while True:
        # Listen for 5-second chunks to detect the wake word
        audio_data = record_audio(duration=5)
        detected_text = transcribe_audio(audio_data).lower()
        print(f"Detected text: {detected_text}")

        if "hello" in detected_text:
            print("Wake word detected!")
            time.sleep(1)  # Brief pause before recording command
            print("Listening for your command...")
            
            # Record command until silence or noise is detected
            command_audio = record_audio_until_silence_or_noise()
            
            # Transcribe the command
            command_text = transcribe_audio(command_audio)
            print(f"You said: {command_text}")
            
            # Reset wake word timer after command detection
            wake_word_timer = 0.0  
            print("Please say the word `hello` for the next command")
            continue  
     # If wake word isn't detected, increment inactivity timer
         
        time.sleep(1)
        
        wake_word_timer += 8  # 6-second recording + 1 second sleep +1 second print commnd execution maybe
        
        if wake_word_timer >= wake_word_timeout:
            print("No activity detected for 7 seconds. Exiting...")
            exit()  # Exit the program

def main():
    """Main function that waits for the wake word, then records and transcribes the command."""
    while True:
        listen_for_wake_word()

if __name__ == "__main__":
    main()
