import whisper
import sounddevice as sd
import numpy as np
import queue
import time
import torch
import os
import scipy.io.wavfile as wav
import webrtcvad  # Ensure this is installed: pip install webrtcvad

class VoiceAssistant:
    # Class-level audio configuration
    SAMPLE_RATE = 16000  # Supported by WebRTC VAD
    CHANNELS = 1         # Mono audio
    BLOCKSIZE = 1024     # Size of each audio chunk

    def __init__(self, model_name="small", vad_mode=3):
        """
        Initialize the voice assistant.
        Loads the Whisper model, initializes an audio queue, and sets up VAD.
        """
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = whisper.load_model(model_name, device=self.device)
        self.audio_queue = queue.Queue()
        self.vad = webrtcvad.Vad(vad_mode)  # Mode 3: Most aggressive

    def callback(self, indata, frames, time_info, status):
        """
        Callback to capture microphone input and place it in a queue.
        """
        if status:
            print(status)
        self.audio_queue.put(indata.copy())

    def record_audio(self, duration):
        """
        Records raw audio for a fixed duration without any filtering.
        Returns a NumPy array containing the audio.
        """
        print(f"Recording raw audio for {duration} seconds...")
        audio_data = []
        with sd.InputStream(samplerate=self.SAMPLE_RATE, channels=self.CHANNELS,
                            callback=self.callback, blocksize=self.BLOCKSIZE):
            num_blocks = int(self.SAMPLE_RATE / self.BLOCKSIZE * duration)
            for _ in range(num_blocks):
                audio_data.append(self.audio_queue.get())
        return np.concatenate(audio_data, axis=0)

    def record_filtered_audio(self, silence_duration, noise_duration, RMS_THRESHOLD):
        """
        Records audio continuously until a period of silence or white noise is detected.
        This function is used both for command and wake word recordings.
        Parameters:
          silence_duration: Seconds of silence (no speech and low RMS) required to stop.
          noise_duration: Seconds of detected white noise required to stop.
          RMS_THRESHOLD: RMS value below which the audio is considered low volume.
        Returns the recorded audio as a NumPy array.
        """
        print("Recording filtered audio until silence or white noise is detected...")
        audio_data = []
        silence_timer = 0.0
        noise_timer = 0.0

        with sd.InputStream(samplerate=self.SAMPLE_RATE, channels=self.CHANNELS,
                            callback=self.callback, blocksize=self.BLOCKSIZE):
            while True:
                audio_chunk = self.audio_queue.get()
                audio_data.append(audio_chunk)

                rms_value = self.compute_rms(audio_chunk)
                is_speech = self.is_chunk_speech(audio_chunk)
                is_noise = self.is_white_noise(audio_chunk, rms_threshold=RMS_THRESHOLD)

                if not is_speech and rms_value < RMS_THRESHOLD:
                    silence_timer += self.BLOCKSIZE / self.SAMPLE_RATE
                   # print(f"Filtering: no speech | RMS: {rms_value:.6f} (silence_timer = {silence_timer:.2f})")
                else:
                    silence_timer = 0.0
                    #print(f"Filtering: speech or sufficient volume detected (RMS: {rms_value:.6f})")

                if is_noise:
                    noise_timer += self.BLOCKSIZE / self.SAMPLE_RATE
                    #print(f"Filtering: white noise detected (noise_timer = {noise_timer:.2f})")
                else:
                    noise_timer = 0.0

                # Stop recording if either silence or white noise persists
                if silence_timer >= silence_duration or noise_timer >= noise_duration:
                    print("Silence or persistent white noise detected. Ending recording.")
                    break

        return np.concatenate(audio_data, axis=0)

    def record_wake_word_audio(self):
        """
        Records audio for wake word detection using filtering logic.
        Here we use slightly different thresholds (which you can adjust)
        to ensure that the audio contains clear voice before transcription.
        """
        # Adjust these values as needed for wake word clarity:
        wake_silence_duration = 3   # seconds required to detect pause
        wake_noise_duration = 3      # seconds of white noise considered as invalid
        wake_RMS_THRESHOLD = 0.03    # a bit higher to filter out very low volume
        
        print("Recording audio for wake word detection with filtering...")
        return self.record_filtered_audio(wake_silence_duration, wake_noise_duration, wake_RMS_THRESHOLD)

    def is_chunk_speech(self, chunk, frame_duration_ms=30):
        """
        Checks whether an audio chunk contains speech using WebRTC VAD.
        Converts float32 audio to 16-bit PCM and inspects frames.
        Returns True if any frame is classified as speech.
        """
        chunk_int16 = (chunk * 32767).astype(np.int16)
        pcm_bytes = chunk_int16.tobytes()
        frame_size = int(self.SAMPLE_RATE * (frame_duration_ms / 1000.0))
        bytes_per_frame = frame_size * 2  # 16-bit audio has 2 bytes per sample

        for i in range(0, len(pcm_bytes), bytes_per_frame):
            frame = pcm_bytes[i:i+bytes_per_frame]
            if len(frame) < bytes_per_frame:
                break
            if self.vad.is_speech(frame, self.SAMPLE_RATE):
                return True
        return False

    def compute_rms(self, audio_chunk):
        """
        Computes the Root Mean Square (RMS) value of an audio chunk.
        """
        return np.sqrt(np.mean(audio_chunk**2))

    def is_white_noise(self, audio_chunk, rms_threshold=0.08):
        """
        Determines if the audio chunk is white noise based on low RMS
        and low amplitude fluctuation (standard deviation).
        """
        rms_value = self.compute_rms(audio_chunk)
        if rms_value < rms_threshold:
            stddev = np.std(audio_chunk)
            if stddev < 0.02:  # Adjust based on testing
                return True
        return False

    def transcribe_audio(self, audio_array):
        """
        Transcribes the given audio using Whisper.
        Writes the audio to a temporary WAV file, transcribes it, then deletes the file.
        """
        print("Processing audio for transcription...")
        temp_filename = "temp_audio.wav"
        wav.write(temp_filename, self.SAMPLE_RATE, audio_array)
        result = self.model.transcribe(temp_filename)
        os.remove(temp_filename)
        return result['text']

    def listen_for_wake_word(self):
        """
        Continuously listens for the wake word "hello" using filtered recording.
        When the wake word is detected, it then records the command with the same filtering.
        """
        print("Listening for 'hello'...")
        wake_word_timeout = 5.0  # seconds to wait before exiting due to inactivity
        wake_word_timer = 0.0

        while True:
            # Record wake word audio using filtering logic
            wake_audio = self.record_wake_word_audio()
            detected_text = self.transcribe_audio(wake_audio).lower()
            print(f"Detected text (wake word attempt): {detected_text}")

            if "hello" in detected_text:
                print("Wake word detected!")
                time.sleep(1)  # Brief pause before command recording
                print("Listening for your command...")
                # Use command-specific thresholds (can be adjusted separately)
                command_audio = self.record_filtered_audio(
                    silence_duration=3, 
                    noise_duration=3, 
                    RMS_THRESHOLD=0.03
                )
                command_text = self.transcribe_audio(command_audio)
                print(f"You said: {command_text}")
                wake_word_timer = 0.0
                print("Please say the word 'hello' for the next command")
                continue

            # If wake word is not detected, wait a bit before trying again.
            time.sleep(1)
            wake_word_timer += 6 # Approximate elapsed time per iteration in trascribing and detection

            if wake_word_timer >= wake_word_timeout:
                print("No wake word detected for 3 seconds. Exiting...")
                exit()

    def run(self):
        """
        Main loop that continuously listens for the wake word and then commands.
        """
        while True:
            self.listen_for_wake_word()


if __name__ == "__main__":
    assistant = VoiceAssistant()
    assistant.run()

